import EmailClient from "@/components/email-client"

export default function Home() {
  return <EmailClient />
}
